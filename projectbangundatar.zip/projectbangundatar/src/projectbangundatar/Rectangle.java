/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectbangundatar;

/**
 *
 * @author HP
 */
public class Rectangle {
    //attribute
    int width;
    int length;
    
    //methods
    int calculateArea(){
        int area = this.width * this.length;
        return area; 
    }
    
    int calculatePerimeter (){
        int perimeter  = 2 * (width + length);
        return perimeter;
    }
}
    
