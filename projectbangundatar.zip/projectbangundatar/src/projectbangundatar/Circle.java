/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectbangundatar;

/**
 *
 * @author HP
 */
public class Circle {
   //attributes
    double radius;
    
    
    //methods
    double calculateArea (){
         double area = 3.14 * this.radius * this.radius;
         return area;
    }
    
    double calculatePerimeter(){
        double perimeter = 2 * 3.14 * this.radius;
        return perimeter;
    }
}
