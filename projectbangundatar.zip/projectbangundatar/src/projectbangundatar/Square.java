/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectbangundatar;

/**
 *
 * @author HP
 */
public class Square {
    //attribute
    int sideLength;
    
    //methods
 int calculateArea(){
     int area = this.sideLength * this.sideLength;
     return area;
 }
 
 int calculatePerimeter(){
     int perimeter = 4 * this.sideLength;
     return perimeter;
 }
}
