/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projectbangundatar;

/**
 *
 * @author HP
 */
public class Projectbangundatar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    // TODO code application logic here
        
        // Menghitung Luas Persegi A
        Square A = new Square();
        A.sideLength = 5;
        
        int totalPersegi = A.calculateArea();
        System.out.println("Luas persegi adalah: " + totalPersegi + " cm");
        
        // Menhitung Luas Persegi Panjang
        Rectangle B = new Rectangle();
        B.length = 10;
        B.width  = 5;
        
        int totalPersegiPanjang = B.calculateArea();
        System.out.println("Luas persegi panjang adalah: " + totalPersegiPanjang + " cm");
        
        //Menghitung Luas Lingkaran 
        Circle C = new Circle();
        C.radius = 25.0/2;
        
        double totalLingkaran = C.calculateArea();
        System.out.println("Total Luas Lingkaran adalah: " + totalLingkaran + " cm");

        //Contoh Soal:
        //Sebuah persegi memiliki panjang sisi 25 cm, didalamnya
        //terdapat sebuah lingkaran yang diameternya sama dengan panjang persegi. 
        //Hitunglah sisa luas persegi!
        
        Square E = new Square();
        E.sideLength = 25;
        
        Circle F = new Circle();
        F.radius = 25.0/2;
        
        double totalSisaLuas = E.calculateArea() - F.calculateArea();
        System.out.println("Luas daerah yang diarsir adalah: " + totalSisaLuas + " cm");
    } 
    
}
